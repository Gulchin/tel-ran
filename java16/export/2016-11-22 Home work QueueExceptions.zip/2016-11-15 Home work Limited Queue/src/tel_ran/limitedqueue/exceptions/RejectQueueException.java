package tel_ran.limitedqueue.exceptions;

public class RejectQueueException extends Exception {

}
