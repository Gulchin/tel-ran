package tel_ran.limitedqueue.exceptions;

public class IdleQueueException extends RuntimeException {

}
