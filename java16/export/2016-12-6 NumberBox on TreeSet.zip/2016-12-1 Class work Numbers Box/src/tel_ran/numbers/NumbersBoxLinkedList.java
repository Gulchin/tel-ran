package tel_ran.numbers;

import java.util.LinkedList;

public class NumbersBoxLinkedList extends AbstractNumbersBox {

	public NumbersBoxLinkedList() {
		numbers=new LinkedList<>();
	}
	
}
