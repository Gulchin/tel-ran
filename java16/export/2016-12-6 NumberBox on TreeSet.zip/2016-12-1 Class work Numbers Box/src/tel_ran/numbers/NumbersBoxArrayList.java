package tel_ran.numbers;

import java.util.ArrayList;

public class NumbersBoxArrayList extends AbstractNumbersBox {

	public NumbersBoxArrayList() {
		numbers=new ArrayList<Integer>();
	}
 
}
