package tel_ran.employees.dao;

import java.util.Arrays;

import tel_ran.employees.entities.Company;
import tel_ran.employees.entities.Employee;

public class EmployeesRepository {
	private Employee [] employees=new Employee[0];
	
	public Employee getEmployee(int id){
		for (Employee employee: employees){
			if(employee.getId()==id) return employee;
		}
		return null;
	}
	
	public boolean addEmployee(Employee employee){
		if(getEmployee(employee.getId())!=null) return false;
		employees=Arrays.copyOf(employees, employees.length+1);
		employees[employees.length-1]=employee;
		return true;
	}
	
	public boolean removeEmployee(int id){
		Employee[] result=new Employee[employees.length-1];

		int count=0;
		for (int i=0;i<employees.length;i++){
			if (employees[i].getId()!=id)
			{
				//Если мы заполнили весь массив результатов и последний элемент репозитория также не с нужным id
				if(count==employees.length-1) 
					return false;
				result[count++]=employees[i];
			}
		}
		employees=result;
		return true;	
	}
	
	public Employee[] getEmployeeByCompany(Company company){
		Employee[] result=new Employee[employees.length];
		int count=0;
		for (int i=0;i<employees.length;i++){
			if (employees[i].getComapny().equals(company)){
				result[count++]=employees[i];
			}
		}
		return Arrays.copyOf(result, count);
	}
	
	public Employee[] getEmployeeByName(String name){
		Employee[] result=new Employee[employees.length];
		int count=0;
		for (int i=0;i<employees.length;i++){
			if (employees[i].getName().equals(name)){
				result[count++]=employees[i];
			}
		}
		return Arrays.copyOf(result, count);
	}
	
	public Employee[] getEmployeeBySalary(int salaryFrom, int salaryTo){
		Employee[] result=new Employee[employees.length];
		int count=0;
		for (int i=0;i<employees.length;i++){
			int salary=employees[i].getSalary();
			if (salary>=salaryFrom && salary<=salaryTo){
				result[count++]=employees[i];
			}
		}
		return Arrays.copyOf(result, count);
	}
	
	public Employee [] getAll(){
		return Arrays.copyOf(employees,employees.length);
	}
}
