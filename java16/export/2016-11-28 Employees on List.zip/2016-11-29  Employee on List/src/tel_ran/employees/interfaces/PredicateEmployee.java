package tel_ran.employees.interfaces;

import tel_ran.employees.entities.Employee;

public interface PredicateEmployee {
	boolean test(Employee employee);
}
