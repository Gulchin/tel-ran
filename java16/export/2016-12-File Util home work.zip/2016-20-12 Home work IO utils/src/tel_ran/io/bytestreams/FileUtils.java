package tel_ran.io.bytestreams;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class FileUtils {

public static void printFile(String fileName){
	
	try(FileInputStream stream = new FileInputStream(fileName)) 
	{		
		 int length=stream.available();
		 byte[] red= new byte[length];
		 stream.read(red);
		 System.out.println(new String(red));

	} catch (FileNotFoundException e) {
		System.out.println("File "+fileName+" not found");
	} catch (IOException e) {
		System.out.println("Error reading file "+fileName);
	}
}

public static String copyFile(String inputFileName, String outputFileName){

	byte[] red=null;
	try(FileInputStream stream = new FileInputStream(inputFileName)) 
	{		
		 int length=stream.available();
		 red= new byte[length];
		 stream.read(red);

	} catch (FileNotFoundException e) {
		return "File "+inputFileName+" not found";
	} catch (IOException e) {
		return "Error reading file "+inputFileName;
	}
	
	try(FileOutputStream stream = new FileOutputStream(outputFileName)) 
	{		
		 stream.write(red);

	} catch (FileNotFoundException e) {
		return "Invalid path or filename "+outputFileName;
	} catch (IOException e) {
		return "Error writing file "+outputFileName;
	}	
	return 	"File copied";
}

}
